package com.example.myapplication.Domain;

public class SliderItems {
    private String url;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public SliderItems() {
    }
}
